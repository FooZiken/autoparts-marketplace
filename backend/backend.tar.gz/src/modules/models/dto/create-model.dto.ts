import { IsString, IsNumber } from 'class-validator';

export class CreateModelDto {

  @IsString()
  name: string;

  @IsString()
  description: string;

  @IsString()
  stlKey: string;

  @IsNumber()
  price: number;

  @IsString()
  materialId: string;
}