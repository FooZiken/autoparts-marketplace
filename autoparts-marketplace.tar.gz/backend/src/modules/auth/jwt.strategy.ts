import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor() {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      secretOrKey: 'SUPER_SECRET_JWT_KEY',
      ignoreExpiration: false,
    });
  }

  async validate(payload: any) {
  return {
    userId: payload.sub,
    email: payload.email,
    roles: payload.roles,
  };
}

}
